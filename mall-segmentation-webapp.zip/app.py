"""
Mall Customer Segment Finder — Streamlit Web App
------------------------------------------------
A dashboard UI for the K-Means customer segmentation model.

Like the Movie Taste Cluster Finder, this is unsupervised — there's
no single "correct" segment. This app lets you enter a customer's
income and spending score, then shows which of the 5 discovered
segments they'd land in, plotted against everyone else.

BEFORE YOU RUN THIS:
  1. Install dependencies:
       pip install streamlit pandas scikit-learn matplotlib
  2. Make sure "mall_customers.csv" is in this same folder.
  3. Run with:
       streamlit run app.py
"""

import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt
import matplotlib
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

matplotlib.rcParams['font.family'] = 'DejaVu Sans'

INCOME_COL = "Annual Income (k$)"
SPEND_COL = "Spending Score (1-100)"

# ---------------------------------------------------------------------------
# Page config + styling — Boutique Rose & Charcoal theme
# ---------------------------------------------------------------------------

st.set_page_config(page_title="Mall Customer Segment Finder", page_icon="🛍️", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #1C1720; }
    section[data-testid="stSidebar"] { background-color: #26202B; }
    div[data-testid="stMetric"] {
        background-color: #26202B;
        border: 1px solid #3D3444;
        border-radius: 10px;
        padding: 16px;
    }
    div.stButton > button {
        background-color: #D9668B;
        color: #1C1720;
        font-weight: 600;
        border: none;
    }
    div.stButton > button:hover {
        background-color: #E88AA6;
        color: #1C1720;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Fit K-Means once per session
# ---------------------------------------------------------------------------

@st.cache_resource
def load_model():
    df = pd.read_csv("mall_customers.csv")
    X = df[[INCOME_COL, SPEND_COL]]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
    df["Cluster"] = kmeans.fit_predict(X_scaled)

    cluster_means = df.groupby("Cluster")[[INCOME_COL, SPEND_COL]].mean()

    return df, scaler, kmeans, cluster_means


df, scaler, kmeans, cluster_means = load_model()

SEGMENT_NAMES = {}
for c, row in cluster_means.iterrows():
    income, spend = row[INCOME_COL], row[SPEND_COL]
    if income < 45 and spend > 55:
        SEGMENT_NAMES[c] = "Budget-Conscious Big Spenders"
    elif income > 70 and spend < 45:
        SEGMENT_NAMES[c] = "Cautious High Earners"
    elif income > 70 and spend > 55:
        SEGMENT_NAMES[c] = "Premium Customers"
    elif income < 45 and spend < 45:
        SEGMENT_NAMES[c] = "Budget Shoppers"
    else:
        SEGMENT_NAMES[c] = "Average Customers"


# ---------------------------------------------------------------------------
# Sidebar — Model Control
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown("## 🛍️ Model Control")
    st.markdown("### Model Info")
    st.markdown("🔹 **Algorithm:** K-Means Clustering")
    st.markdown(f"🔹 **Dataset:** {len(df)} customers")
    st.markdown("🔹 **Segments:** 5 customer groups")
    st.markdown("---")
    st.markdown("### Note")
    st.caption("K-Means is unsupervised — there's no 'correct' segment, just groups the model found in the data.")


# ---------------------------------------------------------------------------
# Main panel
# ---------------------------------------------------------------------------

st.title("Mall Customer Segment Finder")
st.caption("Enter a customer's income and spending score to find their segment.")

st.markdown("---")

col1, col2 = st.columns([1, 1.4])

with col1:
    st.markdown("### Customer Profile")
    income = st.slider("Annual Income (k$)", 10, 140, 60)
    spend = st.slider("Spending Score (1-100)", 1, 100, 55)

    find_clicked = st.button("🛍️ Find My Segment", type="primary")

with col2:
    if find_clicked:
        user_vec = np.array([[income, spend]])
        user_scaled = scaler.transform(user_vec)
        cluster = kmeans.predict(user_scaled)[0]
        label = SEGMENT_NAMES[cluster]

        st.markdown(f"### Segment: **{label}**")

        fig, ax = plt.subplots(figsize=(7.5, 5.8), dpi=150)
        fig.patch.set_facecolor('#1C1720')
        ax.set_facecolor('#1C1720')

        palette = ['#D9668B', '#E8A33D', '#6B8FD9', '#6BAF8A', '#B08FE8']
        for c in sorted(df["Cluster"].unique()):
            sub = df[df["Cluster"] == c]
            alpha = 1.0 if c == cluster else 0.35
            size = 60 if c == cluster else 40
            ax.scatter(sub[INCOME_COL], sub[SPEND_COL], color=palette[c % len(palette)],
                       alpha=alpha, s=size, edgecolor='#1C1720', linewidth=0.5,
                       label=SEGMENT_NAMES[c] if c == cluster else None)

        ax.scatter([income], [spend], color='white', s=220, marker='*',
                   edgecolor=palette[cluster % len(palette)], linewidth=2, zorder=5, label='You')

        ax.set_xlabel("Annual Income (k$)", color="#D8D4DC", fontsize=11)
        ax.set_ylabel("Spending Score (1-100)", color="#D8D4DC", fontsize=11)
        ax.tick_params(colors="#8B8791")
        for spine in ax.spines.values():
            spine.set_color("#3D3444")
        ax.legend(frameon=False, labelcolor="#D8D4DC", fontsize=9, loc='upper left')
        ax.grid(True, linestyle='--', linewidth=0.5, color="#3D3444", alpha=0.6)

        st.pyplot(fig)

        similar = df[df["Cluster"] == cluster].head(5)
        st.markdown("#### 👥 A Few Customers Like You")
        st.dataframe(similar[["CustomerID", "Age", INCOME_COL, SPEND_COL]], hide_index=True, use_container_width=True)
    else:
        st.info("Set the income and spending score, then click **Find My Segment**.")
